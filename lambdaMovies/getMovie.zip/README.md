run npm install
to create a zip folder for getMovie
run the zip command within the getMovie directory

 zip -r ../getmovie.zip ./*

If problems with node_modules then 

 npm cache clean --force
 npm audit fix --force

